# Bandwidth Manager (non-root)

A monitoring + alerting app for Android hotspot bandwidth. No root required.

## What it actually does

- Lets you set a minimum reserved speed (KB/s) for your own phone via a slider.
- Runs a foreground service that samples real mobile throughput once per second.
- On devices where you grant **Usage Access**, it separates **your own** traffic from
  **tethered/hotspot** traffic using Android's `NetworkStats.Bucket.UID_TETHERING` bucket
  (a real, documented Android API - not a hack, but see caveat below).
- If your own speed drops below your threshold for ~4 seconds straight, it raises a
  high-priority notification with a one-tap link straight into hotspot settings so you can
  pause it.

## What it can't do (and why), stated plainly

- **It cannot shape or split bandwidth itself.** Real QoS/traffic-shaping on the hotspot
  interface requires `iptables`/`tc` access, which needs root.
- **It cannot auto-toggle the hotspot on/off.** `WifiManager.setWifiApEnabled()` has required
  a system-signature permission since Android 8 — third-party apps are blocked from calling it
  on stock, non-rooted devices. That's why this app alerts + deep-links instead of flipping the
  switch for you.
- **The own/tethered split needs Usage Access**, a user-grantable permission (Settings > Apps >
  Special app access > Usage access) — not root. If usage access is denied, or if a given
  device/ROM doesn't cooperate with the `NetworkStatsManager` tethering-bucket query, the app
  falls back to showing combined mobile throughput only (still useful, just less specific) and
  says so in the UI.

## If you want true auto-toggle later

Two real, non-root paths exist if you want to extend this:
1. **Shizuku** - one-time ADB pairing (not root) grants your app shell-level privileges,
   which *can* call the hidden hotspot-toggle APIs. Add the `dev.rikka.shizuku` dependency and
   guard the toggle call behind a Shizuku permission check.
2. **A travel router** (GL.iNet etc.) paired to your phone's hotspot - the router does real
   QoS on its WAN-in side. Different hardware, but genuinely shapes bandwidth.

## Building

1. Open this folder in Android Studio (Koala or newer).
2. Let Gradle sync (needs `google()`/`mavenCentral()` — same repos any Android project uses).
3. Run on a device with `minSdk 26+`.
4. On first launch: grant notification permission, then open Usage Access settings from the
   in-app card and enable it for this app.
5. Set your minimum, tap **Start monitoring**.

This project was written and reviewed for correctness but not compiled/run on a physical
device in this environment (no Android SDK/emulator available here) — do a normal build/test
pass in Android Studio before relying on it.
