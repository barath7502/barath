package com.barath.bandwidthmanager

import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.TrafficStats

/**
 * Splits current mobile-radio throughput into:
 *   - "own"     = bytes used by apps running on THIS phone
 *   - "tethered"= bytes relayed to/from hotspot-connected devices
 *
 * How this works without root:
 * NetworkStatsManager exposes a special pseudo-UID, NetworkStats.Bucket.UID_TETHERING (-5),
 * that Android itself uses to bucket traffic forwarded to tethered clients, separately from
 * any app's own UID. Reading it requires the user to grant "Usage access" for this app
 * (Settings > Apps > Special app access > Usage access) - PACKAGE_USAGE_STATS is a
 * user-grantable permission, NOT a root/system permission.
 *
 * Caveat (documented honestly, not glossed over): querySummary() for TYPE_MOBILE technically
 * wants a subscriberId (IMSI). On API 29+, TelephonyManager.getSubscriberId() is itself
 * restricted for non-carrier-privileged apps. In practice, passing null works for apps that
 * already hold usage-access, because the platform's own Settings > Data Usage screen uses the
 * same call. If it throws on a given device/ROM, we fall back to a total-mobile-interface
 * delta (TrafficStats) which can't distinguish own vs. tethered - the UI clearly indicates
 * which mode is active.
 */
data class SpeedSample(
    val ownBytesPerSec: Long,
    val tetheredBytesPerSec: Long,
    val totalBytesPerSec: Long,
    val precise: Boolean // true = own/tethered split is real, false = fallback total-only
)

class TrafficReader(private val context: Context) {

    private val nsm by lazy {
        context.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
    }

    private var lastTotalRx = -1L
    private var lastTotalTx = -1L
    private var lastTimestamp = -1L

    fun hasUsageAccess(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        val mode = appOps.unsafeCheckOpNoThrow(
            android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            context.packageName
        )
        return mode == android.app.AppOpsManager.MODE_ALLOWED
    }

    /** Call this roughly once per second (or whatever your poll interval is). */
    fun sample(intervalMillis: Long): SpeedSample {
        // Try the precise split first.
        preciseSplitOrNull(intervalMillis)?.let { return it }

        // Fallback: total mobile interface delta only, no own/tethered split.
        val now = System.currentTimeMillis()
        val rx = TrafficStats.getMobileRxBytes()
        val tx = TrafficStats.getMobileTxBytes()

        val sample = if (lastTimestamp > 0 && rx >= lastTotalRx) {
            val elapsedSec = ((now - lastTimestamp).coerceAtLeast(1)) / 1000.0
            val totalRate = ((rx - lastTotalRx) + (tx - lastTotalTx)) / elapsedSec
            SpeedSample(
                ownBytesPerSec = 0,
                tetheredBytesPerSec = 0,
                totalBytesPerSec = totalRate.toLong(),
                precise = false
            )
        } else {
            SpeedSample(0, 0, 0, precise = false)
        }
        lastTotalRx = rx
        lastTotalTx = tx
        lastTimestamp = now
        return sample
    }

    private fun preciseSplitOrNull(intervalMillis: Long): SpeedSample? {
        if (!hasUsageAccess()) return null
        return try {
            val end = System.currentTimeMillis()
            val start = end - intervalMillis

            var ownBytes = 0L
            var tetheredBytes = 0L

            // subscriberId = null: works on many devices when usage-access is granted.
            // Wrapped in try/catch; if it fails we fall back below.
            val stats: NetworkStats = nsm.querySummary(
                ConnectivityManager.TYPE_MOBILE,
                null,
                start,
                end
            )

            val bucket = NetworkStats.Bucket()
            while (stats.hasNextBucket()) {
                stats.getNextBucket(bucket)
                val bytes = bucket.rxBytes + bucket.txBytes
                if (bucket.uid == NetworkStats.Bucket.UID_TETHERING) {
                    tetheredBytes += bytes
                } else {
                    ownBytes += bytes
                }
            }
            stats.close()

            val elapsedSec = (intervalMillis.coerceAtLeast(1)) / 1000.0
            SpeedSample(
                ownBytesPerSec = (ownBytes / elapsedSec).toLong(),
                tetheredBytesPerSec = (tetheredBytes / elapsedSec).toLong(),
                totalBytesPerSec = ((ownBytes + tetheredBytes) / elapsedSec).toLong(),
                precise = true
            )
        } catch (e: SecurityException) {
            null
        } catch (e: Exception) {
            null
        }
    }
}
