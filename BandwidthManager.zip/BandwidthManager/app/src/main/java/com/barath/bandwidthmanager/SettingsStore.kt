package com.barath.bandwidthmanager

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "bandwidth_manager_settings")

object Keys {
    val MIN_KB_PER_SEC = intPreferencesKey("min_kb_per_sec")
    val AUTO_MANAGE_ENABLED = booleanPreferencesKey("auto_manage_enabled")
}

class SettingsStore(private val context: Context) {

    val minKbPerSec: Flow<Int> = context.dataStore.data.map { it[Keys.MIN_KB_PER_SEC] ?: 100 }

    val autoManageEnabled: Flow<Boolean> =
        context.dataStore.data.map { it[Keys.AUTO_MANAGE_ENABLED] ?: false }

    suspend fun setMinKbPerSec(value: Int) {
        context.dataStore.edit { it[Keys.MIN_KB_PER_SEC] = value }
    }

    suspend fun setAutoManageEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_MANAGE_ENABLED] = value }
    }
}
