package com.barath.bandwidthmanager

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var settings: SettingsStore
    private lateinit var reader: TrafficReader

    private val notifPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsStore(this)
        reader = TrafficReader(this)

        if (Build.VERSION.SDK_INT >= 33) {
            notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    BandwidthManagerScreen(
                        settings = settings,
                        hasUsageAccess = { reader.hasUsageAccess() },
                        onOpenUsageAccess = {
                            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                        },
                        onOpenHotspotSettings = {
                            startActivity(
                                Intent("android.settings.TETHER_SETTINGS")
                            )
                        },
                        onStartMonitor = {
                            startForegroundService(Intent(this, SpeedMonitorService::class.java))
                        },
                        onStopMonitor = {
                            stopService(Intent(this, SpeedMonitorService::class.java))
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun BandwidthManagerScreen(
    settings: SettingsStore,
    hasUsageAccess: () -> Boolean,
    onOpenUsageAccess: () -> Unit,
    onOpenHotspotSettings: () -> Unit,
    onStartMonitor: () -> Unit,
    onStopMonitor: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val thresholdKb by settings.minKbPerSec.collectAsStateWithLifecycle(initialValue = 100)
    val autoEnabled by settings.autoManageEnabled.collectAsStateWithLifecycle(initialValue = false)
    val uiState by MonitorState.state.collectAsStateWithLifecycle()

    var sliderValue by remember(thresholdKb) { mutableStateOf(thresholdKb.toFloat()) }
    var usageAccessGranted by remember { mutableStateOf(hasUsageAccess()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text("Bandwidth Manager", style = MaterialTheme.typography.headlineMedium)

        Text(
            "Reserve a minimum speed for your phone. Hotspot devices get everything above that. " +
                "If your speed falls below the minimum, you'll be alerted to pause the hotspot.",
            style = MaterialTheme.typography.bodyMedium
        )

        // --- Threshold setting ---
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Minimum reserved for you: ${sliderValue.toInt()} KB/s")
                Slider(
                    value = sliderValue,
                    onValueChange = { sliderValue = it },
                    onValueChangeFinished = {
                        scope.launch { settings.setMinKbPerSec(sliderValue.toInt()) }
                    },
                    valueRange = 10f..2000f,
                    steps = 198
                )
            }
        }

        // --- Permission gate ---
        if (!usageAccessGranted) {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Grant Usage Access so this app can tell your own traffic apart from " +
                            "hotspot traffic. Without it, only combined mobile throughput is shown."
                    )
                    Button(onClick = onOpenUsageAccess) { Text("Open Usage Access settings") }
                    Button(onClick = { usageAccessGranted = hasUsageAccess() }) {
                        Text("I granted it - recheck")
                    }
                }
            }
        }

        // --- Live status ---
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Live status", style = MaterialTheme.typography.titleMedium)
                if (!uiState.running) {
                    Text("Monitor not running.")
                } else if (uiState.precise) {
                    Text("Your phone: %.0f KB/s".format(uiState.ownKbPerSec))
                    Text("Hotspot devices: %.0f KB/s".format(uiState.tetheredKbPerSec))
                } else {
                    Text("Combined mobile throughput: %.0f KB/s (split unavailable)".format(uiState.totalKbPerSec))
                }
                when (uiState.advice) {
                    HotspotAdvice.PAUSE_RECOMMENDED -> Text(
                        "⚠ Below your reserved minimum - pause the hotspot.",
                        color = MaterialTheme.colorScheme.error
                    )
                    HotspotAdvice.OK -> if (uiState.running) Text("✓ Within your reserved minimum")
                    else -> {}
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onStartMonitor) { Text("Start monitoring") }
            OutlinedButton(onClick = onStopMonitor) { Text("Stop") }
        }

        OutlinedButton(onClick = onOpenHotspotSettings, modifier = Modifier.fillMaxWidth()) {
            Text("Open hotspot settings")
        }

        Divider()

        Text(
            "Note: Android doesn't let non-root apps auto-toggle the hotspot or truly shape " +
                "bandwidth between your phone and tethered devices. This app measures real " +
                "throughput and alerts you to act - it can't enforce the split itself.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
