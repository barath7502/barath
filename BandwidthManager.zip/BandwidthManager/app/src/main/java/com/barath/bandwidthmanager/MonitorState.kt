package com.barath.bandwidthmanager

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class HotspotAdvice { OK, PAUSE_RECOMMENDED, UNKNOWN }

data class MonitorUiState(
    val running: Boolean = false,
    val ownKbPerSec: Double = 0.0,
    val tetheredKbPerSec: Double = 0.0,
    val totalKbPerSec: Double = 0.0,
    val precise: Boolean = false,
    val advice: HotspotAdvice = HotspotAdvice.UNKNOWN
)

/** Simple in-process shared state (service -> UI). No root, no IPC needed since
 *  both run in the same app process. */
object MonitorState {
    private val _state = MutableStateFlow(MonitorUiState())
    val state = _state.asStateFlow()

    fun update(newState: MonitorUiState) {
        _state.value = newState
    }
}
