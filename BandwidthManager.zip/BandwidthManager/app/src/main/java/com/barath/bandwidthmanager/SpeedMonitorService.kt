package com.barath.bandwidthmanager

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Foreground service that polls real mobile throughput once per second, compares your
 * own phone's usage against the minimum-reserved threshold, and:
 *   - keeps the persistent notification updated with live own/hotspot speed
 *   - if your own speed drops below the threshold for a few consecutive samples
 *     (debounced, so a single blip doesn't trigger it), raises a high-priority
 *     notification recommending you pause the hotspot, with a one-tap action that
 *     opens hotspot settings directly (no auto-toggle - see README for why).
 */
class SpeedMonitorService : Service() {

    companion object {
        const val CHANNEL_STATUS = "bandwidth_status"
        const val CHANNEL_ALERT = "bandwidth_alert"
        const val NOTIF_ID_STATUS = 1001
        const val NOTIF_ID_ALERT = 1002
        const val POLL_INTERVAL_MS = 1000L
        const val CONSECUTIVE_LOW_SAMPLES_TO_ALERT = 4 // ~4 seconds under threshold before alerting
    }

    private val scope = CoroutineScope(Dispatchers.Default + Job())
    private lateinit var reader: TrafficReader
    private lateinit var settings: SettingsStore
    private var lowStreak = 0
    private var alerted = false

    override fun onCreate() {
        super.onCreate()
        reader = TrafficReader(this)
        settings = SettingsStore(this)
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID_STATUS, buildStatusNotification(0.0, 0.0, true))
        scope.launch { monitorLoop() }
        return START_STICKY
    }

    private suspend fun monitorLoop() {
        val thresholdKb = settings.minKbPerSec.first()
        while (true) {
            val sample = reader.sample(POLL_INTERVAL_MS)
            val ownKb = sample.ownBytesPerSec / 1024.0
            val tetheredKb = sample.tetheredBytesPerSec / 1024.0
            val totalKb = sample.totalBytesPerSec / 1024.0

            // If we can't split own/tethered on this device, we conservatively judge
            // against total throughput instead - still useful, just less specific.
            val comparisonKb = if (sample.precise) ownKb else totalKb
            val currentThreshold = settings.minKbPerSec.first()

            val advice = if (comparisonKb < currentThreshold) {
                lowStreak++
                if (lowStreak >= CONSECUTIVE_LOW_SAMPLES_TO_ALERT) HotspotAdvice.PAUSE_RECOMMENDED
                else HotspotAdvice.OK
            } else {
                lowStreak = 0
                alerted = false
                HotspotAdvice.OK
            }

            MonitorState.update(
                MonitorUiState(
                    running = true,
                    ownKbPerSec = ownKb,
                    tetheredKbPerSec = tetheredKb,
                    totalKbPerSec = totalKb,
                    precise = sample.precise,
                    advice = advice
                )
            )

            updateStatusNotification(ownKb, tetheredKb, sample.precise)

            if (advice == HotspotAdvice.PAUSE_RECOMMENDED && !alerted) {
                alerted = true
                showAlertNotification(comparisonKb, currentThreshold)
            }

            delay(POLL_INTERVAL_MS)
        }
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_STATUS, "Bandwidth status", NotificationManager.IMPORTANCE_LOW
            )
        )
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ALERT, "Low speed alerts", NotificationManager.IMPORTANCE_HIGH
            )
        )
    }

    private fun hotspotSettingsIntent(): PendingIntent {
        // No public, non-root API can toggle the hotspot for us - this deep-links
        // straight into the system hotspot screen so you can pause it in one tap.
        val intent = Intent("android.settings.TETHER_SETTINGS").apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun buildStatusNotification(ownKb: Double, tetheredKb: Double, precise: Boolean): Notification {
        val text = if (precise) {
            "You: %.0f KB/s  •  Hotspot: %.0f KB/s".format(ownKb, tetheredKb)
        } else {
            "Monitoring total mobile throughput (own/hotspot split unavailable on this device)"
        }
        return NotificationCompat.Builder(this, CHANNEL_STATUS)
            .setContentTitle("Bandwidth Manager active")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setOngoing(true)
            .build()
    }

    private fun updateStatusNotification(ownKb: Double, tetheredKb: Double, precise: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID_STATUS, buildStatusNotification(ownKb, tetheredKb, precise))
    }

    private fun showAlertNotification(currentKb: Double, thresholdKb: Int) {
        val notif = NotificationCompat.Builder(this, CHANNEL_ALERT)
            .setContentTitle("Your speed is below your reserved minimum")
            .setContentText(
                "%.0f KB/s < %d KB/s reserved. Tap to pause the hotspot.".format(currentKb, thresholdKb)
            )
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(hotspotSettingsIntent())
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID_ALERT, notif)
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.coroutineContext[Job]?.cancel()
        MonitorState.update(MonitorUiState(running = false))
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
